ROLLBACK_CONFIG = {
    "max_execution_time": 45,
    "min_depth": 10000,
    "safe_wallet_address": "0x123...def"
}
