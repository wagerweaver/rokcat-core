CONFIG = {
    "min_discount": 0.10,     # 10% discount threshold
    "min_volume": 10000,      # Minimum liquidity requirement
    "exit_threshold": 0.03    # 3% reversion exit barrier
}
