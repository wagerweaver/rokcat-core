# Core bridge routing engine
