# Track and update bridge latency data
