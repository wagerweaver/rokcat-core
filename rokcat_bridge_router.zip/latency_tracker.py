class LatencyDB:
    def get_latency(self, provider):
        return 10  # mock latency

    def update_latency(self, provider, time_sec):
        pass
