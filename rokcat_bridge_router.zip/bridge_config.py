BRIDGE_CONFIG = {
    "max_latency_sec": 30,
    "min_success_rate": 0.9,
    "fallback_depth": 3
}
