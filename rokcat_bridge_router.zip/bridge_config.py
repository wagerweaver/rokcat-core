# Configurable bridge settings
