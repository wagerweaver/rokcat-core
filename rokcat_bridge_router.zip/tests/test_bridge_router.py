# Unit tests for bridge routing logic
