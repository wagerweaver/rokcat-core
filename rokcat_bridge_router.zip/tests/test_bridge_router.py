# Tests for bridge routing and fallback
