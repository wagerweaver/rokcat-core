# Quote ranking and fallback scoring logic
