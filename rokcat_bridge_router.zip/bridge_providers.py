# Unified API wrappers for Squid, Stargate, etc.
