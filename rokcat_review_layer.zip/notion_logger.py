import requests

class NotionLogger:
    def __init__(self, db_id, token):
        self.db_id = db_id
        self.token = token

    def send(self, entry):
        # Placeholder — implement Notion DB record creation
        pass
