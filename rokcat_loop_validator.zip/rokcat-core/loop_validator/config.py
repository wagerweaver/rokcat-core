
MAX_SLIPPAGE = 0.5  # in %
MIN_SPREAD_MULTIPLIER = 1.1  # must exceed fees by 10%
