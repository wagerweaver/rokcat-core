CONFIG = {
    "private_key": "0xabc...",
    "gas_thresholds": {
        "Ethereum": 60,
        "Polygon": 30
    }
}
