CONFIG = {
    "min_score": 0.55,
    "max_spread": 2.0  # Percentage
}
