TRUSTED_TOKENS = {
    "USDC": 0.95,
    "ETH": 0.9,
    "SHIB": 0.4,
    "UNKNOWN": 0.2
}
